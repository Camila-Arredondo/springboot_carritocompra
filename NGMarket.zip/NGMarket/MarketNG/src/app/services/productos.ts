export class Productos {
    id : number = 0;
    nombre : string = '';
    descripcion : string = '';
    categoria : string = '';
    precio : number = 0;
}