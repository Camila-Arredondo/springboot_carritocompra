import { Component, OnInit} from '@angular/core';
import { Productos } from 'src/app/services/productos';
import { AbstractControl, FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ProductosService } from 'src/app/services/productos.service';
import { ActivatedRoute, Router } from '@angular/router';

import Swal from 'sweetalert2';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit{

  titleCreate : string = "Registra un nuevo producto";
  titleUpdate : string = "Actualiza los datos del producto";
  producto: Productos = new Productos();
  submitted : boolean = false;

  form: FormGroup = new FormGroup({
    
    nombre : new FormControl(''),
    categoria : new FormControl(''),
    descripcion : new FormControl(''),
    precio : new FormControl('')
  })

  constructor(
    private formBuilder: FormBuilder,
    private productoService: ProductosService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

ngOnInit(): void {
  this.getProducto();
  this.form = this.formBuilder.group(
    {
      nombre : [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(50)
        ]
      ],
      categoria : [
        '',
          [
            Validators.required,
          ]
      ],
      descripcion : [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(200)
        ]
      ],
      precio : [
        0,
        [
          Validators.required,
          Validators.min(0)
        ]
      ], 
    }
  )
}

get f():  { [key: string] : AbstractControl } {
  return this.form.controls;
}

onSubmit() : void {
  this.submitted = true;
  if(this.form.invalid){
    return;
  }
  this.createProducto();
}

onReset(): void {
  this.submitted = false;
  this.form.reset();
}

createProducto() : void {
  this.productoService.createProducto(this.producto).subscribe(
    producto => {
      console.log(producto);
      this.router.navigate(['/productos']);
      Swal.fire({
        icon: 'success',
        title: 'Nuevo producto registrado',
        text: 'El producto ' + producto.nombre + ' ' + ' ha sido registrado satisfactoriamente',
      });
    }
  );
}

getProducto(): void {
  this.activatedRoute.params.subscribe(params => {
    let id = params['id'];
    if(id){
      this.productoService.getProducto(id).subscribe(
        (producto) => this.producto = producto
      )
    }
  });
}

updateProducto(): void {
  this.productoService.updateProducto(this.producto).subscribe(
    producto => {
      this.router.navigateByUrl('/productos');
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: 'Datos actualizados',
        text: `Los datos del producto ${producto.producto.nombre}  se han actualizado correctamente`,
        timer: 2000,
        showConfirmButton: false,
      });
    }
  );
}

}
